module mux2to1 (
    input wire D0,
    input wire D1,
    input wire S,
    output wire Y
);

    assign Y = S ? D1 : D0;

endmodule


module mux4to1 (
    input wire D0,
    input wire D1,
    input wire D2,
    input wire D3,
    input wire [1:0] S,
    output wire Y
);

    wire Y1, Y2;

    mux2to1 u1 (.D0(D0), .D1(D1), .S(S[0]), .Y(Y1));
    mux2to1 u2 (.D0(D2), .D1(D3), .S(S[0]), .Y(Y2));

    mux2to1 u3 (.D0(Y1), .D1(Y2), .S(S[1]), .Y(Y));

endmodule


module mux16to1 (
    input wire [15:0] D,
    input wire [3:0] S,
    output wire Y
);

    wire Y0, Y1, Y2, Y3;

    mux4to1 m0 (
        .D0(D[0]),
        .D1(D[1]),
        .D2(D[2]),
        .D3(D[3]),
        .S(S[1:0]),
        .Y(Y0)
    );

    mux4to1 m1 (
        .D0(D[4]),
        .D1(D[5]),
        .D2(D[6]),
        .D3(D[7]),
        .S(S[1:0]),
        .Y(Y1)
    );

    mux4to1 m2 (
        .D0(D[8]),
        .D1(D[9]),
        .D2(D[10]),
        .D3(D[11]),
        .S(S[1:0]),
        .Y(Y2)
    );

    mux4to1 m3 (
        .D0(D[12]),
        .D1(D[13]),
        .D2(D[14]),
        .D3(D[15]),
        .S(S[1:0]),
        .Y(Y3)
    );

    mux4to1 m4 (
        .D0(Y0),
        .D1(Y1),
        .D2(Y2),
        .D3(Y3),
        .S(S[3:2]),
        .Y(Y)
    );

endmodule