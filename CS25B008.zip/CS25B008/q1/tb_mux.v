`timescale 1ns / 1ps

module tb_mux;

    reg [15:0] D;
    reg [3:0] S;
    wire Y;

    integer i;

    // Connect testbench to 16:1 MUX
    mux16to1 uut (
        .D(D),
        .S(S),
        .Y(Y)
    );

    initial begin

        // -------- DATA PATTERN 1 --------
        D = 16'b1011001110101101;

        for (i = 0; i < 16; i = i + 1) begin

            S = i;
            #10;

            if (Y !== D[i])
                $display("FAIL: S=%b Y=%b Expected=%b",
                         S, Y, D[i]);
            else
                $display("PASS: S=%b Y=%b",
                         S, Y);

        end


        // -------- DATA PATTERN 2 --------
        D = 16'b0101010101010101;

        for (i = 0; i < 16; i = i + 1) begin

            S = i;
            #10;

            if (Y !== D[i])
                $display("FAIL: S=%b Y=%b Expected=%b",
                         S, Y, D[i]);
            else
                $display("PASS: S=%b Y=%b",
                         S, Y);

        end

        $display("Simulation completed.");

        $finish;

    end

endmodule