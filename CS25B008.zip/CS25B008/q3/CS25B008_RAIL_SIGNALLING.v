`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/06/2026 02:18:55 PM
// Design Name: 
// Module Name: CS25B008_RAIL_SIGNALLING
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module railway_controller (

    input wire E,
    input wire W,

    input wire P1_BUSY,
    input wire P2_BUSY,
    input wire P3_BUSY,

    input wire PRI,

    output reg E_GREEN,
    output reg E_RED,

    output reg W_GREEN,
    output reg W_RED,

    output reg E_P1,
    output reg E_P2,
    output reg E_P3,

    output reg W_P1,
    output reg W_P2,
    output reg W_P3
);

always @(*) begin

    // Default values
    E_GREEN = 0;
    E_RED   = 1;

    W_GREEN = 0;
    W_RED   = 1;

    E_P1 = 0;
    E_P2 = 0;
    E_P3 = 0;

    W_P1 = 0;
    W_P2 = 0;
    W_P3 = 0;


    // -----------------------------------
    // Only East train
    // -----------------------------------
    if (E == 1 && W == 0) begin

        if (P1_BUSY == 0) begin
            E_GREEN = 1;
            E_RED = 0;
            E_P1 = 1;
        end

        else if (P2_BUSY == 0) begin
            E_GREEN = 1;
            E_RED = 0;
            E_P2 = 1;
        end

        else if (P3_BUSY == 0) begin
            E_GREEN = 1;
            E_RED = 0;
            E_P3 = 1;
        end

    end


    // -----------------------------------
    // Only West train
    // -----------------------------------
    else if (E == 0 && W == 1) begin

        if (P1_BUSY == 0) begin
            W_GREEN = 1;
            W_RED = 0;
            W_P1 = 1;
        end

        else if (P2_BUSY == 0) begin
            W_GREEN = 1;
            W_RED = 0;
            W_P2 = 1;
        end

        else if (P3_BUSY == 0) begin
            W_GREEN = 1;
            W_RED = 0;
            W_P3 = 1;
        end

    end


    // -----------------------------------
    // Both trains
    // -----------------------------------
    else if (E == 1 && W == 1) begin

        // Two or more platforms free

        if ((P1_BUSY + P2_BUSY + P3_BUSY) <= 1) begin

            // East gets first free platform

            if (P1_BUSY == 0) begin
                E_GREEN = 1;
                E_RED = 0;
                E_P1 = 1;

                // West gets next free platform
                if (P2_BUSY == 0) begin
                    W_GREEN = 1;
                    W_RED = 0;
                    W_P2 = 1;
                end
                else if (P3_BUSY == 0) begin
                    W_GREEN = 1;
                    W_RED = 0;
                    W_P3 = 1;
                end
            end

            else if (P2_BUSY == 0) begin
                E_GREEN = 1;
                E_RED = 0;
                E_P2 = 1;

                // West gets P3
                W_GREEN = 1;
                W_RED = 0;
                W_P3 = 1;
            end

            else begin
                // P1 and P2 busy, P3 free
                E_GREEN = 1;
                E_RED = 0;
                E_P3 = 1;

                // No second platform
                W_GREEN = 0;
                W_RED = 1;
            end
        end


        // -----------------------------------
        // Only one platform free
        // PRI decides
        // -----------------------------------

        else if ((P1_BUSY == 0) ||
                 (P2_BUSY == 0) ||
                 (P3_BUSY == 0)) begin

            // PRI = 0 -> East
            if (PRI == 0) begin

                E_GREEN = 1;
                E_RED = 0;

                if (P1_BUSY == 0)
                    E_P1 = 1;
                else if (P2_BUSY == 0)
                    E_P2 = 1;
                else
                    E_P3 = 1;
            end

            // PRI = 1 -> West
            else begin

                W_GREEN = 1;
                W_RED = 0;

                if (P1_BUSY == 0)
                    W_P1 = 1;
                else if (P2_BUSY == 0)
                    W_P2 = 1;
                else
                    W_P3 = 1;
            end
        end

    end

end

endmodule