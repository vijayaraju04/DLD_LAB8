`timescale 1ns / 1ps

module tb_railway_controller;

    reg E;
    reg W;
    reg P1_BUSY;
    reg P2_BUSY;
    reg P3_BUSY;
    reg PRI;

    wire E_GREEN;
    wire E_RED;
    wire W_GREEN;
    wire W_RED;

    wire E_P1;
    wire E_P2;
    wire E_P3;

    wire W_P1;
    wire W_P2;
    wire W_P3;


    railway_controller uut (
        .E(E),
        .W(W),

        .P1_BUSY(P1_BUSY),
        .P2_BUSY(P2_BUSY),
        .P3_BUSY(P3_BUSY),

        .PRI(PRI),

        .E_GREEN(E_GREEN),
        .E_RED(E_RED),

        .W_GREEN(W_GREEN),
        .W_RED(W_RED),

        .E_P1(E_P1),
        .E_P2(E_P2),
        .E_P3(E_P3),

        .W_P1(W_P1),
        .W_P2(W_P2),
        .W_P3(W_P3)
    );


    initial begin

        // 1. No trains
        E = 0; W = 0;
        P1_BUSY = 0; P2_BUSY = 0; P3_BUSY = 0;
        PRI = 0;
        #10;


        // 2. East only -> P1
        E = 1; W = 0;
        P1_BUSY = 0; P2_BUSY = 0; P3_BUSY = 0;
        PRI = 0;
        #10;


        // 3. West only -> P1
        E = 0; W = 1;
        P1_BUSY = 0; P2_BUSY = 0; P3_BUSY = 0;
        PRI = 0;
        #10;


        // 4. Both -> East P1, West P2
        E = 1; W = 1;
        P1_BUSY = 0; P2_BUSY = 0; P3_BUSY = 0;
        PRI = 0;
        #10;


        // 5. Both -> East P2, West P3
        E = 1; W = 1;
        P1_BUSY = 1; P2_BUSY = 0; P3_BUSY = 0;
        PRI = 0;
        #10;


        // 6. Only P2 free, PRI = 0 -> East
        E = 1; W = 1;
        P1_BUSY = 1; P2_BUSY = 0; P3_BUSY = 1;
        PRI = 0;
        #10;


        // 7. Only P2 free, PRI = 1 -> West
        E = 1; W = 1;
        P1_BUSY = 1; P2_BUSY = 0; P3_BUSY = 1;
        PRI = 1;
        #10;


        // 8. All platforms busy
        E = 1; W = 1;
        P1_BUSY = 1; P2_BUSY = 1; P3_BUSY = 1;
        PRI = 0;
        #10;


        $finish;

    end

endmodule