`timescale 1ns / 1ps

module tb_demux;

    reg D;
    reg [1:0] S;

    wire Y0;
    wire Y1;
    wire Y2;
    wire Y3;

    // Instantiate the DEMUX
    demux1to4 uut (
        .D(D),
        .S(S),
        .Y0(Y0),
        .Y1(Y1),
        .Y2(Y2),
        .Y3(Y3)
    );

    initial begin

     

        D = 0;
        S = 2'b00;
        #10;

        S = 2'b01;
        #10;

        S = 2'b10;
        #10;

        S = 2'b11;
        #10;



        D = 1;
        S = 2'b00;
        #10;

        S = 2'b01;
        #10;

        S = 2'b10;
        #10;

        S = 2'b11;
        #10;


        // End simulation
        $finish;

    end

endmodule