module demux1to4 (
    input wire D,          // Data input
    input wire [1:0] S,    // Select inputs
    output reg Y0,         // Output 0
    output reg Y1,         // Output 1
    output reg Y2,         // Output 2
    output reg Y3          // Output 3
);

    always @(*) begin

        case (S)

            2'b00: begin
                Y0 = D;
                Y1 = 0;
                Y2 = 0;
                Y3 = 0;
            end

            2'b01: begin
                Y0 = 0;
                Y1 = D;
                Y2 = 0;
                Y3 = 0;
            end

            2'b10: begin
                Y0 = 0;
                Y1 = 0;
                Y2 = D;
                Y3 = 0;
            end

            2'b11: begin
                Y0 = 0;
                Y1 = 0;
                Y2 = 0;
                Y3 = D;
            end

        endcase

    end

endmodule